package com.adrianosilva.lisaflowerstore.Objects

class FlowerObject {

    var id: Int? = null
    var name: String? = null
    var description: String? = null
    var price: Double? = null

}